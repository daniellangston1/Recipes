import React, { useState, useEffect } from 'react';
import {Link, navigate } from '@reach/router';
import axios from 'axios';


const Register = (props) => {
    const [confirmReg, setConfirmReg] = useState("");
    const[errors, setErrors] = useState({});

    const [user, setUser] = useState({
        email: "",
        password: "",
        confirmPassword: "",
    });

    const handleChange = (e) => {
        setUser({
            ...user,
            [e.target.name]: e.target.value,
        });
    };

    const register = (e) => {
        e.preventDefault();
        axios
            .post(
                "http://localhost:8000/api/users/register",
                user,
                {
                    withCredentials: true,
                },
            )
                .then((res)=>{
                    console.log("res.data", res.data);

                    setUser({
                        email: "",
                        password: "",
                        confirmPassword: "",
                    });
                    setConfirmReg(
                        "Thank you for registering, you can now log in!",
                    );
                    setErrors({});
                })
                .catch((err)=>{
                    console.log(err);
                    console.log(err.response.data);
                    setErrors(err.response.data.errors);
                });

    };


    return(

        <div>
            <section class="vh-100 gradient-custom">
                <div class="container py-5 h-100">
                    <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card bg-dark text-white" style={{borderRadius:"1rem"}}>
                        <div class="card-body p-5 text-center">

                            <div class="mb-md-5 mt-md-4 pb-5">

                            <h2 class="fw-bold mb-2 text-uppercase">Register</h2>
                            <p class="text-white-50 mb-5">Please enter your login and password!</p>
                            {confirmReg ? <h4 style={{color: "blue"}}> {confirmReg}</h4> : null }
                                <form onSubmit={register}>
                                    <div class="form-outline form-white mb-4">
                                        <input type="email" id="typeEmailX" class="form-control form-control-lg" 
                                        type="email"
                                        name="email"
                                        value={user.email}
                                        onChange={handleChange}
                                        />
                                        <label class="form-label" for="typeEmailX">Email</label>
                                        {errors.email? (
                                        <span className="error-text">{errors.email.message}</span>
                                            ) : null}
                                    </div>
                                    <div class="form-outline form-white mb-4">
                                        <input type="password" name= "password" value={user.password} onChange={handleChange} id="typePasswordX" class="form-control form-control-lg" />
                                        <label class="form-label" for="typePasswordX">Password</label>
                                        {errors.password ? (
                                        <span className="error-text">
                                            {errors.password.message}
                                        </span>
                                        ) : null}
                                    </div>
                                    <div class="form-outline form-white mb-4">
                                        <input type="password" name="confirmPassword" value={user.confirmPassword} onChange={handleChange} id="typePasswordX" class="form-control form-control-lg" />
                                        <label class="form-label" for="typePasswordX">Confirm Password</label>
                                        {errors.confirmPassword ? (
                                        <span className="error-text">
                                            {errors.confirmPassword.message}
                                        </span>
                                        ) : null}
                                    </div>
                                    <button class="btn btn-outline-light btn-lg px-5" type="submit" >Sign Up</button>
                                </form>

                            </div>

                            <div>
                            <p class="mb-0">Already have an account? <Link to="/" class="text-white-50 fw-bold">Login</Link></p>
                            </div>

                        </div>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
        </div>

    )
}

export default Register;
