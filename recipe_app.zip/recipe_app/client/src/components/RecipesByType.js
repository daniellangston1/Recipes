import React, { useState, useEffect } from 'react';
import {Link, navigate } from '@reach/router';
import axios from 'axios';


const RecipesByType = (props) => {


    const [recipeList, setRecipeList] = useState([]);
    const {type} = props;

    useEffect(()=>{
        axios.get(`http://localhost:8000/api/recipes/type/${type}`)
        .then((res)=>{
            console.log(res);
            console.log(res.data);
            setRecipeList(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })

    }, [])

    return(

        <div>
        <nav classNameName="navbar navbar-expand-lg navbar-dark bg-dark">
                <div className="container px-lg-5">
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li className="nav-item"><Link className="nav-link active" aria-current="page" to="/home">Home</Link></li>
                            <li className="nav-item"><Link className="nav-link" to="#!">About</Link></li>
                            <li className="nav-item"><Link className="nav-link" to="#!">Contact</Link></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <header className="py-5">
                <div className="container px-lg-5">
                    <div className="p-4 p-lg-5 bg-light rounded-3 text-center">
                        <div className="m-4 m-lg-5">
                            <h1 className="display-5 fw-bold">Our {type} Options</h1>
                            <Link className="btn btn-primary btn-lg" to="/home">Home</Link>
                        </div>
                    </div>
                </div>
            </header>
            <section className="pt-4">
                    <div className="container px-lg-5">
                        {
                        recipeList?
                        <div className="row gx-lg-5">
                        {
                            recipeList.map((recipe, index)=>(
                                <div key={index} className="col-lg-6 col-xxl-4 mb-5">
                                    <div className="card bg-light border-0 h-100">
                                        <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                                    <div> <Link className="btn btn-primary btn-lg" to={`/recipes/${recipe._id}`}>{recipe.name}</Link></div>
                                                    <h2 className="fs-4 fw-bold"></h2>
                                                    <img className="images" src={recipe.image} alt="meal"></img>
                                        </div>
                                    </div>
                                </div>
                            ))
                        }
                        </div>
                        :null
                        }
                    </div>
            </section>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
            <script src="js/scripts.js"></script>
        </div>

    )
}

export default RecipesByType;