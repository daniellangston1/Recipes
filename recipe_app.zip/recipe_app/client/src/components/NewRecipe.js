import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link, navigate} from '@reach/router';

const NewRecipe = (props)=>{
    const [errors, setErrors] = useState({});

    const [name, setName] = useState("");
    const [image, setImage] = useState("");
    const [ingredients, setIngredients] = useState("");
    const [instructions, setInstructions] = useState("");
    const [nutrition, setNutrition] = useState("");
    const [type, setType] = useState(false);
    const [rating,setRating] = useState("");

    const submitHandler = (e)=>{
        e.preventDefault();

        axios
            .post(
                "http://localhost:8000/api/recipes",
                {
                    name,
                    image,
                    ingredients,
                    instructions,
                    nutrition,
                    type,
                    rating
                },
                { withCredentials: true },
            )
            .then((res) => {
                console.log(res);
                console.log(res.data);
                navigate("/home");
            })
            .catch((err) => {
                console.log("err: ", err);
                console.log("err.response:", err.response);
                console.log("err.response.data:", err.response.data);
                setErrors(err.response.data.errors);
            });
    }
    
    return (
        <div>
            <header
                style={{
                    borderBottom: "5px double lightgray",
                    padding: "10px",
                    margin: "10px",
                }}
            >
                <h1
                    style={{
                        fontSize: "50px",
                        marginLeft: "450px",
                        marginRight: "450px",
                    }}
                >
                    Add a Recipe!
                    </h1>
                <Link to={"/"}>Return Home</Link>
            </header>

            <form onSubmit={submitHandler}>
                <div>
                    <label htmlFor="name">Name</label>
                    <input
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        name="name"
                        type="text"
                    />
                    <br />
                    {errors.name ? <span>{errors.name.message}</span> : null}
                </div>
                <div>
                    <label htmlFor="ingredients">Ingredients</label>
                    <input
                        value={ingredients}
                        onChange={(e) => setIngredients(e.target.value)}
                        name="ingredients"
                        type="text"
                    />
                    <br />
                    {errors.ingredients ? <span>{errors.ingredients.message}</span> : null}
                </div>
                <div>
                    <label htmlFor="instructions">Instructions</label>
                    <input
                        value={instructions}
                        onChange={(e) => setInstructions(e.target.value)}
                        name="instructions"
                        type="text"
                    />
                    <br />
                    {errors.instructions ? <span>{errors.instructions.message}</span> : null}
                </div>
                <div>
                    <label htmlFor="nutrition">Nutrition</label>
                    <input
                        value={nutrition}
                        onChange={(e) => setNutrition(e.target.value)}
                        name="nutrition"
                        type="text"
                    />
                    <br />
                    {errors.nutrition ? <span>{errors.nutrition.message}</span> : null}
                </div>
                <div>
                    <label htmlFor="type">Type</label>
                    <select
                        value={type}
                        onChange={(e) => setType(e.target.value)}
                        name="type"
                        >
                        <option value="none" defaultValue hidden>
                            Select a Recipe
                        </option>
                        <option value="Breakfast">Breakfast</option>
                        <option value="Lunch">Lunch</option>
                        <option value="Dinner">Dinner</option>
                        <option value="Dessert">Dessert</option>
                        <option value="Snack">Snack</option>
                        <option value="Drink">Drink</option>
                    </select>
                    <br />
                    {errors.type ? <span>{errors.type.message}</span> : null}
                </div>

                <div>
                    <label htmlFor="image">Image URL:</label>
                    <input
                        value={image}
                        onChange={(e) => setImage(e.target.value)}
                        name="image"
                        type="text"
                    />
                    <br />
                    {errors.image ? <span>{errors.image.message}</span> : null}
                </div>

                <div>
                    <label htmlFor="rating">rating</label>
                    <input
                        value={rating}
                        onChange={(e) => setRating(e.target.value)}
                        name="rating"
                        type="number"
                        />
                    <br />
                    {errors.rating ? <span>{errors.rating.message}</span> : null}
                </div>

                <button>Add New Recipe</button>
            </form>
        </div>
    );
}

export default NewRecipe;
