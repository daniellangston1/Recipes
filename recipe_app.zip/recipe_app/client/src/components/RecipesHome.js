import React, { useState, useEffect } from 'react';
import {Link, navigate } from '@reach/router';
import axios from 'axios';


const RecipesHome = (props) => {


    const [recipeList, setRecipeList] = useState([]);

    useEffect(()=>{
        axios.get("http://localhost:8000/api/recipes")
        .then((res)=>{
            console.log(res);
            console.log(res.data);
            setRecipeList(res.data);
        })
        .catch((err)=>{
            console.log(err);
        })

    }, [])

    return(
        <div>
                <nav classNameName="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div className="container px-lg-5">
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                                <li className="nav-item"><Link className="nav-link active" to="#!">Add A Recipe!</Link></li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <header className="py-5">
                    <div className="container px-lg-5">
                        <div className="p-4 p-lg-5 bg-light rounded-3 text-center">
                            <div className="m-4 m-lg-5">
                                <h1 className="display-5 fw-bold">Welcome to Our Food Community!</h1>
                                <p className="fs-4">Please feel free to include one of your favorite recipes to our database! Below are the categories of recipes that our members have added.</p>
                                <Link to= '/new' className="btn btn-primary btn-lg">Add a Recipe</Link>
                            </div>
                        </div>
                    </div>
                </header>
                <section className="pt-4">
                    <div className="container px-lg-5">
                        <div className="row gx-lg-5">
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                        <div> <Link to="/type/Breakfast" className="btn btn-primary btn-lg">Breakfast</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Breakfast Menu</h2>
                                        <img className="images" src="https://www.simplyrecipes.com/thmb/bsHl85dfGja_VuQlhVpM7knVIIM=/2000x1334/filters:no_upscale():max_bytes(150000):strip_icc()/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2006__05__Oatmeal-Pancakes-LEAD-1-355558f808104ae6adf48d88ac9e32cb.jpg" alt="Our Breakfast Menu"></img>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                    <div> <Link to="/type/Lunch" className="btn btn-primary btn-lg">Lunch</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Lunch Menu</h2>
                                        <img className="images" src="https://assets.bonappetit.com/photos/59aee0d01be36d2aa4ae09d5/master/w_1600%2Cc_limit/gojuchang-ranch-crispy-chicken-bowl.jpg" alt="Our Lunch Menu"></img>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                        <div> <Link to="/type/Dinner" className="btn btn-primary btn-lg">Dinner</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Dinner Menu</h2>
                                        <img className="images" src="https://hips.hearstapps.com/ghk.h-cdn.co/assets/16/38/1474395998-ghk-0216-comfortfoodcover-meatballs.jpg?crop=0.856xw:0.571xh;0.0224xw,0.296xh&resize=640:*" alt="Our Dinner Menu"></img>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                        <div> <Link to="/type/Dessert" className="btn btn-primary btn-lg">Dessert</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Dessert Menu</h2>
                                        <img className="images" src="https://www.talktotucker.com/talk/wp-content/uploads/2019/01/Best_Dessert_Spots_Indy_Cake.jpg" alt="Our Dessert Menu"></img>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                        <div> <Link to="/type/Snack" className="btn btn-primary btn-lg">Snacks</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Snack Menu</h2>
                                        <img className="images" src="https://149366112.v2.pressablecdn.com/wp-content/uploads/2013/11/Raw-Protein-Balls1.jpg" alt="Our Snack Menu"></img>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-6 col-xxl-4 mb-5">
                                <div className="card bg-light border-0 h-100">
                                    <div className="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                        <div> <Link to="/type/Drink" className="btn btn-primary btn-lg">Drinks</Link></div>
                                        <h2 className="fs-4 fw-bold">Our Cocktail Menu</h2>
                                        <img className="images" src="https://mediacdn.grabone.co.nz/asset/xjGgV40A0S/box=970x0" alt="Our Cocktail Menu"></img>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
                <script src="js/scripts.js"></script>
                </div>

    )
}

export default RecipesHome;