import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";

const OneRecipe = (props) => {
    const { id } = props;

    const [recipe, setRecipe] = useState({});

    useEffect(() => {

        axios
            .get(`http://localhost:8000/api/recipes/${id}`)
            .then((res) => {
                console.log(res.data);
                console.log(props.location.state);
                setRecipe(res.data);
            })
            .catch((err) => console.log(err));
    }, []);

    const deleteRecipe = (idFromBelow) => {
        axios
            .delete(`http://localhost:8000/api/recipes/${idFromBelow}`)
            .then((res) => {
                console.log(res.data);
                navigate("/home");
            })
            .catch((err) => {
                console.log(err);
            });
    };

    return(

        <div>

<header>
                <h1
                    style={{
                        fontSize: "50px",
                        borderBottom: "5px double lightgray",
                        marginLeft: "450px",
                        marginRight: "450px",
                    }}
                >
                    {recipe.name}
                </h1>
                <div> <Link to={'/home'} className="btn btn-primary btn-lg">Return Home</Link></div>
            </header>

            <img src={recipe.image} />
            <p>{recipe.ingredients}</p>
            <p>{recipe.instructions}</p>
            <p>{recipe.nutrition}</p>

            <div onClick={(e) => deleteRecipe(recipe._id)} className="btn btn-primary btn-lg">Delete</div>
            <div> <Link to={`/recipes/edit/${recipe._id}`} className="btn btn-primary btn-lg">Edit Recipe</Link></div>
        </div>

    )
};



export default OneRecipe;