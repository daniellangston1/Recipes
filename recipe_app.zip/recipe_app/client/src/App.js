
import React, { useEffect } from 'react';
import {Router} from '@reach/router';
import RecipesByType from './components/RecipesByType.js';
import './App.css';
import RecipesHome from './components/RecipesHome.js';
import Login from './components/Login';
import Register from './components/Register';
import OneRecipe from './components/OneRecipe';
import NewRecipe from './components/NewRecipe';
import EditRecipe from './components/EditRecipe';

function App() {
  return (
    <div className="App">
      <Router>
        <Login path="/"/>
        <Register path="/register"/>
        <RecipesHome path="/home"/>
        <NewRecipe path="/new"/>
        <RecipesByType path="/type/:type"/>
        <OneRecipe path="/recipes/:id"/>
        <EditRecipe path="/recipes/edit/:id"/>
      </Router>
    </div>
  );
}

export default App;
